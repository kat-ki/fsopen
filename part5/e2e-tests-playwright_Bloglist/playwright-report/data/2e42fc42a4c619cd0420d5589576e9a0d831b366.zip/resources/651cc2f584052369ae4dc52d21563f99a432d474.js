import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9bc6a7d6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9bc6a7d6"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=9bc6a7d6"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Blog = ({ blog, handleLike, deleteBlog, user }) => {
  _s();
  const [show, setShow] = useState(false);
  const containerStyles = {
    paddingTop: 0,
    paddingLeft: 10,
    border: "solid",
    borderColor: "lightgrey",
    borderWidth: 1,
    marginBottom: 2,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%"
  };
  const detailedBlogStyles = {
    paddingTop: 4,
    paddingLeft: 4,
    borderWidth: 1,
    marginBottom: 5
  };
  const likesBoxStyle = {
    paddingTop: 0,
    width: "60%",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  };
  const likeButtonStyles = {
    backgroundColor: "forestgreen",
    color: "white",
    borderRadius: "5px",
    padding: "6px",
    boxShadow: "none",
    borderColor: "inherit",
    fontFamily: "sans-serif"
  };
  const viewHideButtonStyles = {
    backgroundColor: !show ? "lightgreen" : "lightcoral",
    color: "black",
    padding: "10px 20px",
    margin: "10px",
    borderRadius: "5px",
    boxShadow: "0",
    borderColor: "inherit",
    fontFamily: "sans-serif",
    fontSize: "14px",
    textAlign: "center",
    cursor: "pointer",
    outline: "none"
  };
  const deleteButtonStyles = {
    backgroundColor: "red",
    color: "white",
    padding: "10px 20px",
    margin: "10px",
    borderRadius: "5px",
    boxShadow: "0",
    borderColor: "inherit",
    fontFamily: "sans-serif",
    fontSize: "14px",
    textAlign: "center",
    cursor: "pointer",
    outline: "none"
  };
  const handleShow = () => setShow(!show);
  return /* @__PURE__ */ jsxDEV("div", { style: containerStyles, children: [
    !show ? /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "title", children: /* @__PURE__ */ jsxDEV("b", { children: blog.title }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 77,
        columnNumber: 46
      }, this) }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 77,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: blog.author }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 78,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 76,
      columnNumber: 15
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: detailedBlogStyles, className: "blog", children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        "Title: ",
        /* @__PURE__ */ jsxDEV("b", { children: blog.title }, void 0, false, {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 81,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 81,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "Author: ",
        blog.author
      ] }, void 0, true, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 82,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "Address: ",
        blog.url
      ] }, void 0, true, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 83,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: likesBoxStyle, children: [
        /* @__PURE__ */ jsxDEV("p", { className: "likes", children: [
          "Likes: ",
          blog.likes
        ] }, void 0, true, {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 85,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            style: likeButtonStyles,
            onClick: () => handleLike(blog.id),
            className: "likeBtn",
            children: " Like"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
            lineNumber: 86,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 84,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "blogUserName", children: blog.user.name }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 90,
        columnNumber: 25
      }, this),
      user.name === blog.user.name ? /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "deleteBtn",
          style: deleteButtonStyles,
          onClick: () => deleteBlog(blog.id),
          children: "delete"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 92,
          columnNumber: 9
        },
        this
      ) : null
    ] }, void 0, true, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 80,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: handleShow,
        style: viewHideButtonStyles,
        className: "viewBtn",
        children: !show ? "view" : "hide"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 96,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 74,
    columnNumber: 5
  }, this);
};
_s(Blog, "NKb1ZOdhT+qUsWLXSgjSS2bk2C4=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.object.isRequired,
  handleLike: PropTypes.func.isRequired,
  deleteBlog: PropTypes.func.isRequired,
  user: PropTypes.object.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEU2QzsyQkE1RTdDO0FBQWdCLE1BQU8sY0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUM5QixPQUFPQSxlQUFlO0FBRXRCLE1BQU1DLE9BQU9BLENBQUMsRUFBQ0MsTUFBTUMsWUFBWUMsWUFBWUMsS0FBSSxNQUFNO0FBQUFDLEtBQUE7QUFDbkQsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlDLFNBQVMsS0FBSztBQUd0QyxRQUFNQyxrQkFBa0I7QUFBQSxJQUNwQkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGFBQWE7QUFBQSxJQUNiQyxjQUFjO0FBQUEsSUFDZEMsU0FBUztBQUFBLElBQ1RDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsT0FBTztBQUFBLEVBQ1g7QUFDQSxRQUFNQyxxQkFBcUI7QUFBQSxJQUN2QlYsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiRyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2xCO0FBQ0EsUUFBTU0sZ0JBQWdCO0FBQUEsSUFDbEJYLFlBQVk7QUFBQSxJQUNaUyxPQUFPO0FBQUEsSUFDUEgsU0FBUztBQUFBLElBQ1RDLGdCQUFnQjtBQUFBLElBQWlCQyxZQUFZO0FBQUEsRUFDakQ7QUFDQSxRQUFNSSxtQkFBbUI7QUFBQSxJQUNyQkMsaUJBQWlCO0FBQUEsSUFDakJDLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsSUFDZEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYZCxhQUFhO0FBQUEsSUFDYmUsWUFBWTtBQUFBLEVBQ2hCO0FBQ0EsUUFBTUMsdUJBQXVCO0FBQUEsSUFDekJOLGlCQUFpQixDQUFDakIsT0FBTyxlQUFlO0FBQUEsSUFDeENrQixPQUFPO0FBQUEsSUFDUEUsU0FBUztBQUFBLElBQ1RJLFFBQVE7QUFBQSxJQUNSTCxjQUFjO0FBQUEsSUFDZEUsV0FBVztBQUFBLElBQ1hkLGFBQWE7QUFBQSxJQUNiZSxZQUFZO0FBQUEsSUFDWkcsVUFBVTtBQUFBLElBQ1ZDLFdBQVc7QUFBQSxJQUNYQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLEVBQ2I7QUFDQSxRQUFNQyxxQkFBcUI7QUFBQSxJQUN2QlosaUJBQWlCO0FBQUEsSUFDakJDLE9BQU87QUFBQSxJQUNQRSxTQUFTO0FBQUEsSUFDVEksUUFBUTtBQUFBLElBQ1JMLGNBQWM7QUFBQSxJQUNkRSxXQUFXO0FBQUEsSUFDWGQsYUFBYTtBQUFBLElBQ2JlLFlBQVk7QUFBQSxJQUNaRyxVQUFVO0FBQUEsSUFDVkMsV0FBVztBQUFBLElBQ1hDLFFBQVE7QUFBQSxJQUNSQyxTQUFTO0FBQUEsRUFDYjtBQUdBLFFBQU1FLGFBQWFBLE1BQU03QixRQUFRLENBQUNELElBQUk7QUFFdEMsU0FDSSx1QkFBQyxTQUFJLE9BQU9HLGlCQUVKO0FBQUEsS0FBQ0gsT0FBTyx1QkFBQyxTQUNEO0FBQUEsNkJBQUMsT0FBRSxXQUFVLFNBQVEsaUNBQUMsT0FBR0wsZUFBS29DLFNBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0M7QUFBQSxNQUN4Qyx1QkFBQyxPQUFHcEMsZUFBS3FDLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQjtBQUFBLFNBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHSixJQUNFLHVCQUFDLFNBQUksT0FBT2xCLG9CQUFvQixXQUFVLFFBQ3hDO0FBQUEsNkJBQUMsT0FBRTtBQUFBO0FBQUEsUUFBTyx1QkFBQyxPQUFHbkIsZUFBS29DLFNBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsV0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BQzdCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFFBQVNwQyxLQUFLcUM7QUFBQUEsV0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFFBQVVyQyxLQUFLc0M7QUFBQUEsV0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQjtBQUFBLE1BQ3RCLHVCQUFDLFNBQUksT0FBT2xCLGVBQ1I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsU0FBUTtBQUFBO0FBQUEsVUFBUXBCLEtBQUt1QztBQUFBQSxhQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUFPLE9BQU9sQjtBQUFBQSxZQUFrQixTQUFTLE1BQU1wQixXQUFXRCxLQUFLd0MsRUFBRTtBQUFBLFlBQzFELFdBQVU7QUFBQSxZQUFVO0FBQUE7QUFBQSxVQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0JBQWdCeEMsZUFBS0csS0FBS3NDLFFBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEM7QUFBQSxNQUMzQ3RDLEtBQUtzQyxTQUFTekMsS0FBS0csS0FBS3NDLE9BQ3JCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBTyxXQUFVO0FBQUEsVUFBWSxPQUFPUDtBQUFBQSxVQUM3QixTQUFTLE1BQU1oQyxXQUFXRixLQUFLd0MsRUFBRTtBQUFBLFVBQUc7QUFBQTtBQUFBLFFBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNrRCxJQUFZO0FBQUEsU0FicEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNGO0FBQUEsSUFFUjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQU8sU0FBU0w7QUFBQUEsUUFDVCxPQUFPUDtBQUFBQSxRQUNQLFdBQVU7QUFBQSxRQUNiLFdBQUN2QixPQUFPLFNBQVM7QUFBQTtBQUFBLE1BSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlBO0FBQUEsT0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVSO0FBQUNELEdBbkdLTCxNQUFJO0FBQUEyQyxLQUFKM0M7QUFxR05BLEtBQUs0QyxZQUFZO0FBQUEsRUFDYjNDLE1BQU1GLFVBQVU4QyxPQUFPQztBQUFBQSxFQUN2QjVDLFlBQVlILFVBQVVnRCxLQUFLRDtBQUFBQSxFQUMzQjNDLFlBQVlKLFVBQVVnRCxLQUFLRDtBQUFBQSxFQUMzQjFDLE1BQU1MLFVBQVU4QyxPQUFPQztBQUMzQjtBQUVBLGVBQWU5QztBQUFJLElBQUEyQztBQUFBSyxhQUFBTCxJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwiQmxvZyIsImJsb2ciLCJoYW5kbGVMaWtlIiwiZGVsZXRlQmxvZyIsInVzZXIiLCJfcyIsInNob3ciLCJzZXRTaG93IiwidXNlU3RhdGUiLCJjb250YWluZXJTdHlsZXMiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJib3JkZXIiLCJib3JkZXJDb2xvciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsIndpZHRoIiwiZGV0YWlsZWRCbG9nU3R5bGVzIiwibGlrZXNCb3hTdHlsZSIsImxpa2VCdXR0b25TdHlsZXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJjb2xvciIsImJvcmRlclJhZGl1cyIsInBhZGRpbmciLCJib3hTaGFkb3ciLCJmb250RmFtaWx5Iiwidmlld0hpZGVCdXR0b25TdHlsZXMiLCJtYXJnaW4iLCJmb250U2l6ZSIsInRleHRBbGlnbiIsImN1cnNvciIsIm91dGxpbmUiLCJkZWxldGVCdXR0b25TdHlsZXMiLCJoYW5kbGVTaG93IiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJsaWtlcyIsImlkIiwibmFtZSIsIl9jIiwicHJvcFR5cGVzIiwib2JqZWN0IiwiaXNSZXF1aXJlZCIsImZ1bmMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVN0YXRlfSBmcm9tICdyZWFjdCdcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSBcInByb3AtdHlwZXNcIjtcblxuY29uc3QgQmxvZyA9ICh7YmxvZywgaGFuZGxlTGlrZSwgZGVsZXRlQmxvZywgdXNlcn0pID0+IHtcbiAgICBjb25zdCBbc2hvdywgc2V0U2hvd10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICAvLyBzdHlsZXNcbiAgICBjb25zdCBjb250YWluZXJTdHlsZXMgPSB7XG4gICAgICAgIHBhZGRpbmdUb3A6IDAsXG4gICAgICAgIHBhZGRpbmdMZWZ0OiAxMCxcbiAgICAgICAgYm9yZGVyOiAnc29saWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ2xpZ2h0Z3JleScsXG4gICAgICAgIGJvcmRlcldpZHRoOiAxLFxuICAgICAgICBtYXJnaW5Cb3R0b206IDIsXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcbiAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgIHdpZHRoOiAnMTAwJSdcbiAgICB9XG4gICAgY29uc3QgZGV0YWlsZWRCbG9nU3R5bGVzID0ge1xuICAgICAgICBwYWRkaW5nVG9wOiA0LFxuICAgICAgICBwYWRkaW5nTGVmdDogNCxcbiAgICAgICAgYm9yZGVyV2lkdGg6IDEsXG4gICAgICAgIG1hcmdpbkJvdHRvbTogNVxuICAgIH1cbiAgICBjb25zdCBsaWtlc0JveFN0eWxlID0ge1xuICAgICAgICBwYWRkaW5nVG9wOiAwLFxuICAgICAgICB3aWR0aDogJzYwJScsXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgYWxpZ25JdGVtczogJ2NlbnRlcidcbiAgICB9XG4gICAgY29uc3QgbGlrZUJ1dHRvblN0eWxlcyA9IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAnZm9yZXN0Z3JlZW4nLFxuICAgICAgICBjb2xvcjogJ3doaXRlJyxcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAnNXB4JyxcbiAgICAgICAgcGFkZGluZzogJzZweCcsXG4gICAgICAgIGJveFNoYWRvdzogJ25vbmUnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ2luaGVyaXQnLFxuICAgICAgICBmb250RmFtaWx5OiAnc2Fucy1zZXJpZidcbiAgICB9XG4gICAgY29uc3Qgdmlld0hpZGVCdXR0b25TdHlsZXMgPSB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogIXNob3cgPyAnbGlnaHRncmVlbicgOiAnbGlnaHRjb3JhbCcsXG4gICAgICAgIGNvbG9yOiAnYmxhY2snLFxuICAgICAgICBwYWRkaW5nOiAnMTBweCAyMHB4JyxcbiAgICAgICAgbWFyZ2luOiAnMTBweCcsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzVweCcsXG4gICAgICAgIGJveFNoYWRvdzogJzAnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ2luaGVyaXQnLFxuICAgICAgICBmb250RmFtaWx5OiAnc2Fucy1zZXJpZicsXG4gICAgICAgIGZvbnRTaXplOiAnMTRweCcsXG4gICAgICAgIHRleHRBbGlnbjogJ2NlbnRlcicsXG4gICAgICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgICAgICBvdXRsaW5lOiAnbm9uZSdcbiAgICB9XG4gICAgY29uc3QgZGVsZXRlQnV0dG9uU3R5bGVzID0ge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdyZWQnLFxuICAgICAgICBjb2xvcjogJ3doaXRlJyxcbiAgICAgICAgcGFkZGluZzogJzEwcHggMjBweCcsXG4gICAgICAgIG1hcmdpbjogJzEwcHgnLFxuICAgICAgICBib3JkZXJSYWRpdXM6ICc1cHgnLFxuICAgICAgICBib3hTaGFkb3c6ICcwJyxcbiAgICAgICAgYm9yZGVyQ29sb3I6ICdpbmhlcml0JyxcbiAgICAgICAgZm9udEZhbWlseTogJ3NhbnMtc2VyaWYnLFxuICAgICAgICBmb250U2l6ZTogJzE0cHgnLFxuICAgICAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICAgICAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICAgICAgb3V0bGluZTogJ25vbmUnXG4gICAgfVxuICAgIC8vIHN0eWxlcyBlbmRcblxuICAgIGNvbnN0IGhhbmRsZVNob3cgPSAoKSA9PiBzZXRTaG93KCFzaG93KTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgc3R5bGU9e2NvbnRhaW5lclN0eWxlc30+XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgIXNob3cgPyA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGl0bGVcIj48Yj57YmxvZy50aXRsZX08L2I+PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+e2Jsb2cuYXV0aG9yfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDogPGRpdiBzdHlsZT17ZGV0YWlsZWRCbG9nU3R5bGVzfSBjbGFzc05hbWU9XCJibG9nXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5UaXRsZTogPGI+e2Jsb2cudGl0bGV9PC9iPjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPkF1dGhvcjoge2Jsb2cuYXV0aG9yfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPkFkZHJlc3M6IHtibG9nLnVybH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXtsaWtlc0JveFN0eWxlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsaWtlc1wiPkxpa2VzOiB7YmxvZy5saWtlc308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBzdHlsZT17bGlrZUJ1dHRvblN0eWxlc30gb25DbGljaz17KCkgPT4gaGFuZGxlTGlrZShibG9nLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImxpa2VCdG5cIj4gTGlrZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJibG9nVXNlck5hbWVcIj57YmxvZy51c2VyLm5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIubmFtZSA9PT0gYmxvZy51c2VyLm5hbWUgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZGVsZXRlQnRuXCIgc3R5bGU9e2RlbGV0ZUJ1dHRvblN0eWxlc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRlbGV0ZUJsb2coYmxvZy5pZCl9PmRlbGV0ZTwvYnV0dG9uPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVTaG93fVxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17dmlld0hpZGVCdXR0b25TdHlsZXN9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInZpZXdCdG5cIj5cbiAgICAgICAgICAgICAgICB7IXNob3cgPyAndmlldycgOiAnaGlkZSd9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgKVxufVxuXG5CbG9nLnByb3BUeXBlcyA9IHtcbiAgICBibG9nOiBQcm9wVHlwZXMub2JqZWN0LmlzUmVxdWlyZWQsXG4gICAgaGFuZGxlTGlrZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgICBkZWxldGVCbG9nOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICAgIHVzZXI6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZFxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nXG5cbiJdLCJmaWxlIjoiQzovVXNlcnMvZWtyYS9XZWJzdG9ybVByb2plY3RzL2Zzb3Blbi9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9