import {
  require_react
} from "/node_modules/.vite/deps/chunk-CORUIQPR.js?v=9bc6a7d6";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=9bc6a7d6";
export default require_react();
//# sourceMappingURL=react.js.map
