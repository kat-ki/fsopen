import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9bc6a7d6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9bc6a7d6"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=9bc6a7d6"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const formStyles = {
  marginBottom: "10px",
  display: "flex",
  flexDirection: "column",
  width: "100%",
  paddingBottom: "10px"
};
const inputStyles = {
  marginTop: "6px",
  fontSize: "12px",
  fontFamily: "sans-serif"
};
const buttonstyles = {
  backgroundColor: "lightgreen",
  width: "auto",
  color: "black",
  padding: "4px 8px",
  margin: "10px",
  borderRadius: "5px",
  boxShadow: "0",
  borderColor: "inherit",
  fontFamily: "sans-serif",
  fontSize: "14px",
  textAlign: "center",
  cursor: "pointer",
  outline: "none"
};
const BlogForm = ({ createBlog }) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const addBlog = (event) => {
    event.preventDefault();
    createBlog({ title, author, url });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h4", { children: "Add new blog" }, void 0, false, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 46,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, style: formStyles, children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          name: "title",
          placeholder: "title",
          style: inputStyles,
          value: title,
          onChange: ({ target }) => setTitle(target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 48,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          name: "author",
          placeholder: "author",
          style: inputStyles,
          value: author,
          onChange: ({ target }) => setAuthor(target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 54,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          name: "url",
          placeholder: "url",
          style: inputStyles,
          value: url,
          onChange: ({ target }) => setUrl(target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 60,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", style: buttonstyles, children: "Create" }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 67,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 47,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
BlogForm.propTypes = {
  createBlog: PropTypes.func.isRequired
};
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNZOzJCQTdDWjtBQUFnQixNQUFPLGNBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDOUIsT0FBT0EsZUFBZTtBQUV0QixNQUFNQyxhQUFhO0FBQUEsRUFDZkMsY0FBYztBQUFBLEVBQ2RDLFNBQVM7QUFBQSxFQUNUQyxlQUFlO0FBQUEsRUFDZkMsT0FBTztBQUFBLEVBQ1BDLGVBQWU7QUFDbkI7QUFDQSxNQUFNQyxjQUFjO0FBQUEsRUFDaEJDLFdBQVc7QUFBQSxFQUNYQyxVQUFVO0FBQUEsRUFDVkMsWUFBWTtBQUNoQjtBQUNBLE1BQU1DLGVBQWU7QUFBQSxFQUNqQkMsaUJBQWlCO0FBQUEsRUFDakJQLE9BQU87QUFBQSxFQUNQUSxPQUFPO0FBQUEsRUFDUEMsU0FBUztBQUFBLEVBQ1RDLFFBQVE7QUFBQSxFQUNSQyxjQUFjO0FBQUEsRUFDZEMsV0FBVztBQUFBLEVBQ1hDLGFBQWE7QUFBQSxFQUNiUixZQUFZO0FBQUEsRUFDWkQsVUFBVTtBQUFBLEVBQ1ZVLFdBQVc7QUFBQSxFQUNYQyxRQUFRO0FBQUEsRUFDUkMsU0FBUztBQUNiO0FBQ0EsTUFBTUMsV0FBV0EsQ0FBQyxFQUFDQyxXQUFVLE1BQU07QUFBQUMsS0FBQTtBQUMvQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUMsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJRixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDRyxLQUFLQyxNQUFNLElBQUlKLFNBQVMsRUFBRTtBQUVqQyxRQUFNSyxVQUFVQSxDQUFDQyxVQUFVO0FBQ3ZCQSxVQUFNQyxlQUFlO0FBQ3JCWCxlQUFXLEVBQUNFLE9BQU9HLFFBQVFFLElBQUcsQ0FBQztBQUMvQkosYUFBUyxFQUFFO0FBQ1hHLGNBQVUsRUFBRTtBQUNaRSxXQUFPLEVBQUU7QUFBQSxFQUNiO0FBRUEsU0FDSSx1QkFBQyxTQUNHO0FBQUEsMkJBQUMsUUFBRyw0QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCO0FBQUEsSUFDaEIsdUJBQUMsVUFBSyxVQUFVQyxTQUFTLE9BQU8vQixZQUM1QjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBTSxNQUFLO0FBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixPQUFPTTtBQUFBQSxVQUNQLE9BQU9rQjtBQUFBQSxVQUNQLFVBQVUsQ0FBQyxFQUFDVSxPQUFNLE1BQU1ULFNBQVNTLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtzRDtBQUFBLE1BQ3REO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBTSxNQUFLO0FBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixPQUFPN0I7QUFBQUEsVUFDUCxPQUFPcUI7QUFBQUEsVUFDUCxVQUFVLENBQUMsRUFBQ08sT0FBTSxNQUFNTixVQUFVTSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUxyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLdUQ7QUFBQSxNQUN2RDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQU0sTUFBSztBQUFBLFVBQ0wsTUFBSztBQUFBLFVBQ0wsYUFBWTtBQUFBLFVBQ1osT0FBTzdCO0FBQUFBLFVBQ1AsT0FBT3VCO0FBQUFBLFVBQ1AsVUFBVSxDQUFDLEVBQUNLLE9BQU0sTUFBTUosT0FBT0ksT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS29EO0FBQUEsTUFFcEQsdUJBQUMsWUFBTyxNQUFLLFVBQVMsT0FBT3pCLGNBQWMsc0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxTQXBCckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLE9BdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFUjtBQUFDYSxHQXhDS0YsVUFBUTtBQUFBZSxLQUFSZjtBQTBDTkEsU0FBU2dCLFlBQVk7QUFBQSxFQUNqQmYsWUFBWXZCLFVBQVV1QyxLQUFLQztBQUMvQjtBQUVBLGVBQWVsQjtBQUFRLElBQUFlO0FBQUFJLGFBQUFKLElBQUEiLCJuYW1lcyI6WyJQcm9wVHlwZXMiLCJmb3JtU3R5bGVzIiwibWFyZ2luQm90dG9tIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJ3aWR0aCIsInBhZGRpbmdCb3R0b20iLCJpbnB1dFN0eWxlcyIsIm1hcmdpblRvcCIsImZvbnRTaXplIiwiZm9udEZhbWlseSIsImJ1dHRvbnN0eWxlcyIsImJhY2tncm91bmRDb2xvciIsImNvbG9yIiwicGFkZGluZyIsIm1hcmdpbiIsImJvcmRlclJhZGl1cyIsImJveFNoYWRvdyIsImJvcmRlckNvbG9yIiwidGV4dEFsaWduIiwiY3Vyc29yIiwib3V0bGluZSIsIkJsb2dGb3JtIiwiY3JlYXRlQmxvZyIsIl9zIiwidGl0bGUiLCJzZXRUaXRsZSIsInVzZVN0YXRlIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwidXJsIiwic2V0VXJsIiwiYWRkQmxvZyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwicHJvcFR5cGVzIiwiZnVuYyIsImlzUmVxdWlyZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt1c2VTdGF0ZX0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gXCJwcm9wLXR5cGVzXCI7XG5cbmNvbnN0IGZvcm1TdHlsZXMgPSB7XG4gICAgbWFyZ2luQm90dG9tOiAnMTBweCcsXG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICAgIHdpZHRoOiAnMTAwJScsXG4gICAgcGFkZGluZ0JvdHRvbTogJzEwcHgnXG59XG5jb25zdCBpbnB1dFN0eWxlcyA9IHtcbiAgICBtYXJnaW5Ub3A6ICc2cHgnLFxuICAgIGZvbnRTaXplOiAnMTJweCcsXG4gICAgZm9udEZhbWlseTogJ3NhbnMtc2VyaWYnXG59XG5jb25zdCBidXR0b25zdHlsZXMgPSB7XG4gICAgYmFja2dyb3VuZENvbG9yOiAnbGlnaHRncmVlbicsXG4gICAgd2lkdGg6ICdhdXRvJyxcbiAgICBjb2xvcjogJ2JsYWNrJyxcbiAgICBwYWRkaW5nOiAnNHB4IDhweCcsXG4gICAgbWFyZ2luOiAnMTBweCcsXG4gICAgYm9yZGVyUmFkaXVzOiAnNXB4JyxcbiAgICBib3hTaGFkb3c6ICcwJyxcbiAgICBib3JkZXJDb2xvcjogJ2luaGVyaXQnLFxuICAgIGZvbnRGYW1pbHk6ICdzYW5zLXNlcmlmJyxcbiAgICBmb250U2l6ZTogJzE0cHgnLFxuICAgIHRleHRBbGlnbjogJ2NlbnRlcicsXG4gICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgb3V0bGluZTogJ25vbmUnXG59XG5jb25zdCBCbG9nRm9ybSA9ICh7Y3JlYXRlQmxvZ30pID0+IHtcbiAgICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxuICAgIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcbiAgICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXG5cbiAgICBjb25zdCBhZGRCbG9nID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgY3JlYXRlQmxvZyh7dGl0bGUsIGF1dGhvciwgdXJsfSlcbiAgICAgICAgc2V0VGl0bGUoJycpXG4gICAgICAgIHNldEF1dGhvcignJylcbiAgICAgICAgc2V0VXJsKCcnKVxuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDQ+QWRkIG5ldyBibG9nPC9oND5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXthZGRCbG9nfSBzdHlsZT17Zm9ybVN0eWxlc30+XG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRpdGxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ0aXRsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXtpbnB1dFN0eWxlc31cbiAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHt0YXJnZXR9KSA9PiBzZXRUaXRsZSh0YXJnZXQudmFsdWUpfS8+XG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImF1dGhvclwiXG4gICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiYXV0aG9yXCJcbiAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e2lucHV0U3R5bGVzfVxuICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXV0aG9yfVxuICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHt0YXJnZXR9KSA9PiBzZXRBdXRob3IodGFyZ2V0LnZhbHVlKX0vPlxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ1cmxcIlxuICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInVybFwiXG4gICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXtpbnB1dFN0eWxlc31cbiAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VybH1cbiAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7dGFyZ2V0fSkgPT4gc2V0VXJsKHRhcmdldC52YWx1ZSl9Lz5cblxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIHN0eWxlPXtidXR0b25zdHlsZXN9PkNyZWF0ZTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICApXG59XG5cbkJsb2dGb3JtLnByb3BUeXBlcyA9IHtcbiAgICBjcmVhdGVCbG9nOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dGb3JtIl0sImZpbGUiOiJDOi9Vc2Vycy9la3JhL1dlYnN0b3JtUHJvamVjdHMvZnNvcGVuL3BhcnQ1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9