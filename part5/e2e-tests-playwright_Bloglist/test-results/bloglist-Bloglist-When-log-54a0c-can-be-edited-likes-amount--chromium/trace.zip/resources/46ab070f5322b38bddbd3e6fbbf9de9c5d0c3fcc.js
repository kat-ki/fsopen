import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9bc6a7d6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=9bc6a7d6"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const styles = {
  success: {
    color: "white",
    backgroundColor: "green",
    padding: "10px",
    margin: "10px 0",
    width: "70%",
    borderRadius: "5px"
  },
  error: {
    color: "white",
    backgroundColor: "red",
    padding: "10px",
    margin: "10px 0",
    width: "70%",
    borderRadius: "5px"
  }
};
const Notification = ({ message, status }) => {
  if (message === null) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { style: status === "success" ? styles.success : styles.error, children: message }, void 0, false, {
    fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Notification.jsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
};
_c = Notification;
Notification.propTypes = {
  message: PropTypes.string,
  status: PropTypes.string.isRequired
};
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJRO0FBMUJSLE9BQU9BLG9CQUFlO0FBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWxDLE1BQU1DLFNBQVM7QUFBQSxFQUNYQyxTQUFTO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLGlCQUFpQjtBQUFBLElBQ2pCQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsRUFDbEI7QUFBQSxFQUNBQyxPQUFPO0FBQUEsSUFDSE4sT0FBTztBQUFBLElBQ1BDLGlCQUFpQjtBQUFBLElBQ2pCQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsRUFDbEI7QUFDSjtBQUNBLE1BQU1FLGVBQWVBLENBQUMsRUFBQ0MsU0FBU0MsT0FBTSxNQUFNO0FBQ3hDLE1BQUlELFlBQVksTUFBTTtBQUNsQixXQUFPO0FBQUEsRUFDWDtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxPQUFPQyxXQUFXLFlBQVlYLE9BQU9DLFVBQVVELE9BQU9RLE9BQVFFLHFCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTJFO0FBRW5GO0FBQUNFLEtBUktIO0FBVU5BLGFBQWFJLFlBQVk7QUFBQSxFQUNyQkgsU0FBU1gsVUFBVWU7QUFBQUEsRUFDbkJILFFBQVFaLFVBQVVlLE9BQU9DO0FBQzdCO0FBRUEsZUFBZU47QUFBWSxJQUFBRztBQUFBSSxhQUFBSixJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwic3R5bGVzIiwic3VjY2VzcyIsImNvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwicGFkZGluZyIsIm1hcmdpbiIsIndpZHRoIiwiYm9yZGVyUmFkaXVzIiwiZXJyb3IiLCJOb3RpZmljYXRpb24iLCJtZXNzYWdlIiwic3RhdHVzIiwiX2MiLCJwcm9wVHlwZXMiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gXCJwcm9wLXR5cGVzXCI7XG5cbmNvbnN0IHN0eWxlcyA9IHtcbiAgICBzdWNjZXNzOiB7XG4gICAgICAgIGNvbG9yOiAnd2hpdGUnLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdncmVlbicsXG4gICAgICAgIHBhZGRpbmc6ICcxMHB4JyxcbiAgICAgICAgbWFyZ2luOiAnMTBweCAwJyxcbiAgICAgICAgd2lkdGg6ICc3MCUnLFxuICAgICAgICBib3JkZXJSYWRpdXM6ICc1cHgnXG4gICAgfSxcbiAgICBlcnJvcjoge1xuICAgICAgICBjb2xvcjogJ3doaXRlJyxcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAncmVkJyxcbiAgICAgICAgcGFkZGluZzogJzEwcHgnLFxuICAgICAgICBtYXJnaW46ICcxMHB4IDAnLFxuICAgICAgICB3aWR0aDogJzcwJScsXG4gICAgICAgIGJvcmRlclJhZGl1czogJzVweCdcbiAgICB9LFxufVxuY29uc3QgTm90aWZpY2F0aW9uID0gKHttZXNzYWdlLCBzdGF0dXN9KSA9PiB7XG4gICAgaWYgKG1lc3NhZ2UgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IHN0eWxlPXtzdGF0dXMgPT09ICdzdWNjZXNzJyA/IHN0eWxlcy5zdWNjZXNzIDogc3R5bGVzLmVycm9yfT57bWVzc2FnZX08L2Rpdj5cbiAgICApXG59XG5cbk5vdGlmaWNhdGlvbi5wcm9wVHlwZXMgPSB7XG4gICAgbWVzc2FnZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgICBzdGF0dXM6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb24iXSwiZmlsZSI6IkM6L1VzZXJzL2VrcmEvV2Vic3Rvcm1Qcm9qZWN0cy9mc29wZW4vcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCJ9