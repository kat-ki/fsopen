import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9bc6a7d6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9bc6a7d6"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx?t=1715948198258";
import blogService from "/src/services/blogs.js?t=1715943679375";
import loginService from "/src/services/login.js";
import Notification from "/src/components/Notification.jsx";
import BlogForm from "/src/components/BlogForm.jsx?t=1715945906188";
const buttonstyles = {
  backgroundColor: "lightgreen",
  color: "black",
  padding: "4px 8px",
  margin: "10px",
  borderRadius: "5px",
  boxShadow: "0",
  borderColor: "inherit",
  fontFamily: "sans-serif",
  fontSize: "14px",
  textAlign: "center",
  cursor: "pointer",
  outline: "none"
};
const buttonWarn = {
  backgroundColor: "lightcoral",
  color: "black",
  padding: "4px 8px",
  margin: "10px",
  borderRadius: "5px",
  boxShadow: "0",
  borderColor: "inherit",
  fontFamily: "sans-serif",
  fontSize: "14px",
  textAlign: "center",
  cursor: "pointer",
  outline: "none"
};
const popularStyles = {
  backgroundColor: "lightBlue",
  width: "30%",
  color: "black",
  padding: "4px 8px",
  margin: "10px",
  borderRadius: "5px",
  boxShadow: "0",
  borderColor: "inherit",
  fontFamily: "sans-serif",
  fontSize: "14px",
  textAlign: "center",
  cursor: "pointer",
  outline: "none"
};
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState(null);
  const [status, setStatus] = useState("");
  const [formVisible, setFormVisible] = useState(false);
  useEffect(() => {
    blogService.getAll().then(
      (blogs2) => setBlogs(blogs2)
    );
  }, []);
  useEffect(() => {
    const loggedUser = window.localStorage.getItem("loggedUser");
    if (loggedUser) {
      const user2 = JSON.parse(loggedUser);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({ username, password });
      window.localStorage.setItem("loggedUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (error) {
      setMessage("Wrong username or password");
      setStatus("error");
      setTimeout(() => {
        setMessage(null);
      }, 2e3);
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "username " }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 96,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          name: "Username",
          "data-testid": "username",
          value: username,
          onChange: ({ target }) => setUsername(target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 97,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 95,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "password " }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 106,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          name: "Password",
          "data-testid": "password",
          value: password,
          onChange: ({ target }) => setPassword(target.value)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 107,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 105,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "log in" }, void 0, false, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 115,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 94,
    columnNumber: 3
  }, this);
  const handleLogout = () => {
    window.localStorage.clear();
    setUser(null);
  };
  const addBlog = async (blog) => {
    if (!blog.title || !blog.author || !blog.url) {
      setMessage("Title, author, and url must not be empty");
      setStatus("error");
      setTimeout(() => {
        setMessage(null);
      }, 2e3);
      return;
    }
    try {
      const response = await blogService.create(blog);
      setMessage(`Added ${response.title}`);
      setStatus("success");
      setTimeout(() => {
        setMessage(null);
      }, 2e3);
      setBlogs([...blogs, response]);
      setFormVisible(false);
    } catch (error) {
      setMessage(error.message);
      setStatus("error");
      setTimeout(() => {
        setMessage(null);
      }, 2e3);
    }
  };
  const createBlogForm = () => {
    return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(
        BlogForm,
        {
          createBlog: addBlog
        },
        void 0,
        false,
        {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 153,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setFormVisible(false), style: buttonWarn, children: "cancel" }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 156,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 152,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 151,
      columnNumber: 7
    }, this);
  };
  const toggleFormVisibility = () => {
    setFormVisible(!formVisible);
  };
  const handleLike = async (id) => {
    const foundBlog = blogs.find((b) => b.id === id);
    if (foundBlog) {
      const updatedLikes = { ...foundBlog, likes: foundBlog.likes + 1 };
      try {
        const response = await blogService.updateLikes(id, updatedLikes);
        const updatedBlogs = blogs.map((b) => b.id === id ? response : b);
        setBlogs(updatedBlogs);
      } catch (error) {
        setMessage(error.message);
      }
    }
  };
  const showPopular = () => {
    const sortedByLikes = [...blogs].sort((a, b) => b.likes - a.likes);
    setBlogs(sortedByLikes);
  };
  const deleteBlog = async (id) => {
    const foundBlog = blogs.find((b) => b.id === id);
    if (foundBlog && window.confirm(`Delete ${foundBlog.title} by ${foundBlog.author}?`)) {
      try {
        await blogService.deleteBlog(foundBlog.id);
        setBlogs((prevBlogs) => prevBlogs.filter((b) => b.id !== foundBlog.id));
        setMessage(`Deleted ${foundBlog.title}`);
        setTimeout(() => {
          setMessage(null);
        }, 3e3);
        setStatus("success");
      } catch (error) {
        setMessage(error.message);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }, children: [
    /* @__PURE__ */ jsxDEV("h2", { style: { margin: "20px" }, children: "Blogs" }, void 0, false, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 200,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, status }, void 0, false, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 201,
      columnNumber: 13
    }, this),
    user === null ? loginForm() : /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { style: { margin: "10px" }, className: "loggedUser", children: [
        /* @__PURE__ */ jsxDEV("b", { children: user.name }, void 0, false, {
          fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 205,
          columnNumber: 77
        }, this),
        " logged in "
      ] }, void 0, true, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 205,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, style: buttonWarn, children: "log out" }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 206,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { margin: "10px" }, children: formVisible ? createBlogForm() : /* @__PURE__ */ jsxDEV("button", { onClick: toggleFormVisibility, style: buttonstyles, children: "add blog" }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 211,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 207,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { style: popularStyles, onClick: showPopular, children: "Show popular" }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 214,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { margin: "10px" }, children: blogs.map(
        (blog) => /* @__PURE__ */ jsxDEV(
          Blog,
          {
            blog,
            handleLike,
            deleteBlog,
            user
          },
          blog.id,
          false,
          {
            fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
            lineNumber: 217,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 215,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 204,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 199,
    columnNumber: 5
  }, this);
};
_s(App, "WtP9PiDbvpK6nUbpMX2ELwSUvm0=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/ekra/WebstormProjects/fsopen/part5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZnQjsyQkEvRmhCO0FBQWtCQSxvQkFBZ0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGNBQWM7QUFFckIsTUFBTUMsZUFBZTtBQUFBLEVBQ2pCQyxpQkFBaUI7QUFBQSxFQUNqQkMsT0FBTztBQUFBLEVBQ1BDLFNBQVM7QUFBQSxFQUNUQyxRQUFRO0FBQUEsRUFDUkMsY0FBYztBQUFBLEVBQ2RDLFdBQVc7QUFBQSxFQUNYQyxhQUFhO0FBQUEsRUFDYkMsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFBQSxFQUNWQyxXQUFXO0FBQUEsRUFDWEMsUUFBUTtBQUFBLEVBQ1JDLFNBQVM7QUFDYjtBQUNBLE1BQU1DLGFBQWE7QUFBQSxFQUNmWixpQkFBaUI7QUFBQSxFQUNqQkMsT0FBTztBQUFBLEVBQ1BDLFNBQVM7QUFBQSxFQUNUQyxRQUFRO0FBQUEsRUFDUkMsY0FBYztBQUFBLEVBQ2RDLFdBQVc7QUFBQSxFQUNYQyxhQUFhO0FBQUEsRUFDYkMsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFBQSxFQUNWQyxXQUFXO0FBQUEsRUFDWEMsUUFBUTtBQUFBLEVBQ1JDLFNBQVM7QUFDYjtBQUNBLE1BQU1FLGdCQUFnQjtBQUFBLEVBQ2xCYixpQkFBaUI7QUFBQSxFQUNqQmMsT0FBTztBQUFBLEVBQ1BiLE9BQU87QUFBQSxFQUNQQyxTQUFTO0FBQUEsRUFDVEMsUUFBUTtBQUFBLEVBQ1JDLGNBQWM7QUFBQSxFQUNkQyxXQUFXO0FBQUEsRUFDWEMsYUFBYTtBQUFBLEVBQ2JDLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQUEsRUFDVkMsV0FBVztBQUFBLEVBQ1hDLFFBQVE7QUFBQSxFQUNSQyxTQUFTO0FBQ2I7QUFFQSxNQUFNSSxNQUFNQSxNQUFNO0FBQUFDLEtBQUE7QUFDZCxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUMsU0FBUyxFQUFFO0FBRXJDLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJRixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDRyxVQUFVQyxXQUFXLElBQUlKLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNLLE1BQU1DLE9BQU8sSUFBSU4sU0FBUyxJQUFJO0FBRXJDLFFBQU0sQ0FBQ08sU0FBU0MsVUFBVSxJQUFJUixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDUyxRQUFRQyxTQUFTLElBQUlWLFNBQVMsRUFBRTtBQUV2QyxRQUFNLENBQUNXLGFBQWFDLGNBQWMsSUFBSVosU0FBUyxLQUFLO0FBQ3BEMUIsWUFBVSxNQUFNO0FBQ1pFLGdCQUFZcUMsT0FBTyxFQUFFQztBQUFBQSxNQUFLLENBQUFoQixXQUN0QkMsU0FBU0QsTUFBSztBQUFBLElBQ2xCO0FBQUEsRUFDSixHQUFHLEVBQUU7QUFDTHhCLFlBQVUsTUFBTTtBQUNaLFVBQU15QyxhQUFhQyxPQUFPQyxhQUFhQyxRQUFRLFlBQVk7QUFDM0QsUUFBSUgsWUFBWTtBQUNaLFlBQU1WLFFBQU9jLEtBQUtDLE1BQU1MLFVBQVU7QUFDbENULGNBQVFELEtBQUk7QUFDWjdCLGtCQUFZNkMsU0FBU2hCLE1BQUtpQixLQUFLO0FBQUEsSUFDbkM7QUFBQSxFQUNKLEdBQUcsRUFBRTtBQUNMLFFBQU1DLGNBQWMsT0FBT0MsVUFBVTtBQUNqQ0EsVUFBTUMsZUFBZTtBQUNyQixRQUFJO0FBQ0EsWUFBTXBCLFFBQU8sTUFBTTVCLGFBQWFpRCxNQUFNLEVBQUN6QixVQUFVRSxTQUFRLENBQUM7QUFDMURhLGFBQU9DLGFBQWFVLFFBQVEsY0FBY1IsS0FBS1MsVUFBVXZCLEtBQUksQ0FBQztBQUM5RDdCLGtCQUFZNkMsU0FBU2hCLE1BQUtpQixLQUFLO0FBQy9CaEIsY0FBUUQsS0FBSTtBQUNaSCxrQkFBWSxFQUFFO0FBQ2RFLGtCQUFZLEVBQUU7QUFBQSxJQUNsQixTQUFTeUIsT0FBTztBQUNackIsaUJBQVcsNEJBQTRCO0FBQ3ZDRSxnQkFBVSxPQUFPO0FBQ2pCb0IsaUJBQVcsTUFBTTtBQUNidEIsbUJBQVcsSUFBSTtBQUFBLE1BQ25CLEdBQUcsR0FBSTtBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ0EsUUFBTXVCLFlBQVlBLE1BQ2QsdUJBQUMsVUFBSyxVQUFVUixhQUNaO0FBQUEsMkJBQUMsU0FDRztBQUFBLDZCQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csTUFBSztBQUFBLFVBQ0wsTUFBSztBQUFBLFVBQ0wsZUFBWTtBQUFBLFVBQ1osT0FBT3RCO0FBQUFBLFVBQ1AsVUFBVSxDQUFDLEVBQUMrQixPQUFNLE1BQU05QixZQUFZOEIsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3NEO0FBQUEsU0FQMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxTQUNHO0FBQUEsNkJBQUMsVUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNmO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxlQUFZO0FBQUEsVUFDWixPQUFPOUI7QUFBQUEsVUFDUCxVQUFVLENBQUMsRUFBQzZCLE9BQU0sTUFBTTVCLFlBQVk0QixPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLc0Q7QUFBQSxTQVAxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsT0FyQmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSixRQUFNQyxlQUFlQSxNQUFNO0FBQ3ZCbEIsV0FBT0MsYUFBYWtCLE1BQU07QUFDMUI3QixZQUFRLElBQUk7QUFBQSxFQUNoQjtBQUNBLFFBQU04QixVQUFVLE9BQU9DLFNBQVM7QUFDNUIsUUFBSSxDQUFDQSxLQUFLQyxTQUFTLENBQUNELEtBQUtFLFVBQVUsQ0FBQ0YsS0FBS0csS0FBSztBQUMxQ2hDLGlCQUFXLDBDQUEwQztBQUNyREUsZ0JBQVUsT0FBTztBQUNqQm9CLGlCQUFXLE1BQU07QUFDYnRCLG1CQUFXLElBQUk7QUFBQSxNQUNuQixHQUFHLEdBQUk7QUFDUDtBQUFBLElBQ0o7QUFFQSxRQUFJO0FBQ0EsWUFBTWlDLFdBQVcsTUFBTWpFLFlBQVlrRSxPQUFPTCxJQUFJO0FBQzlDN0IsaUJBQVksU0FBUWlDLFNBQVNILEtBQU0sRUFBQztBQUNwQzVCLGdCQUFVLFNBQVM7QUFDbkJvQixpQkFBVyxNQUFNO0FBQ2J0QixtQkFBVyxJQUFJO0FBQUEsTUFDbkIsR0FBRyxHQUFJO0FBQ1BULGVBQVMsQ0FBQyxHQUFHRCxPQUFPMkMsUUFBUSxDQUFDO0FBQzdCN0IscUJBQWUsS0FBSztBQUFBLElBQ3hCLFNBQVNpQixPQUFPO0FBQ1pyQixpQkFBV3FCLE1BQU10QixPQUFPO0FBQ3hCRyxnQkFBVSxPQUFPO0FBQ2pCb0IsaUJBQVcsTUFBTTtBQUNidEIsbUJBQVcsSUFBSTtBQUFBLE1BQ25CLEdBQUcsR0FBSTtBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ0EsUUFBTW1DLGlCQUFpQkEsTUFBTTtBQUN6QixXQUNJLHVCQUFDLFNBQ0csaUNBQUMsU0FDRztBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxZQUFZUDtBQUFBQTtBQUFBQSxRQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFDd0I7QUFBQSxNQUV4Qix1QkFBQyxZQUFPLFNBQVMsTUFBTXhCLGVBQWUsS0FBSyxHQUFHLE9BQU9uQixZQUFZLHNCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsU0FKM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsRUFFUjtBQUNBLFFBQU1tRCx1QkFBdUJBLE1BQU07QUFDL0JoQyxtQkFBZSxDQUFDRCxXQUFXO0FBQUEsRUFDL0I7QUFDQSxRQUFNa0MsYUFBYSxPQUFPQyxPQUFPO0FBQzdCLFVBQU1DLFlBQVlqRCxNQUFNa0QsS0FBSyxDQUFBQyxNQUFLQSxFQUFFSCxPQUFPQSxFQUFFO0FBQzdDLFFBQUlDLFdBQVc7QUFDWCxZQUFNRyxlQUFlLEVBQUMsR0FBR0gsV0FBV0ksT0FBT0osVUFBVUksUUFBUSxFQUFDO0FBQzlELFVBQUk7QUFDQSxjQUFNVixXQUFXLE1BQU1qRSxZQUFZNEUsWUFBWU4sSUFBSUksWUFBWTtBQUMvRCxjQUFNRyxlQUFldkQsTUFBTXdELElBQUksQ0FBQUwsTUFBS0EsRUFBRUgsT0FBT0EsS0FBS0wsV0FBV1EsQ0FBQztBQUM5RGxELGlCQUFTc0QsWUFBWTtBQUFBLE1BQ3pCLFNBQVN4QixPQUFPO0FBQ1pyQixtQkFBV3FCLE1BQU10QixPQUFPO0FBQUEsTUFDNUI7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQUNBLFFBQU1nRCxjQUFjQSxNQUFNO0FBQ3RCLFVBQU1DLGdCQUFnQixDQUFDLEdBQUcxRCxLQUFLLEVBQUUyRCxLQUFLLENBQUNDLEdBQUdULE1BQU1BLEVBQUVFLFFBQVFPLEVBQUVQLEtBQUs7QUFDakVwRCxhQUFTeUQsYUFBYTtBQUFBLEVBQzFCO0FBQ0EsUUFBTUcsYUFBYSxPQUFPYixPQUFPO0FBQzdCLFVBQU1DLFlBQVlqRCxNQUFNa0QsS0FBSyxDQUFBQyxNQUFLQSxFQUFFSCxPQUFPQSxFQUFFO0FBQzdDLFFBQUlDLGFBQWEvQixPQUFPNEMsUUFBUyxVQUFTYixVQUFVVCxLQUFNLE9BQU1TLFVBQVVSLE1BQU8sR0FBRSxHQUFHO0FBQ2xGLFVBQUk7QUFDQSxjQUFNL0QsWUFBWW1GLFdBQVdaLFVBQVVELEVBQUU7QUFDekMvQyxpQkFBUyxDQUFBOEQsY0FBYUEsVUFBVUMsT0FBTyxDQUFBYixNQUFLQSxFQUFFSCxPQUFPQyxVQUFVRCxFQUFFLENBQUM7QUFDbEV0QyxtQkFBWSxXQUFVdUMsVUFBVVQsS0FBTSxFQUFDO0FBQ3ZDUixtQkFBVyxNQUFNO0FBQ2J0QixxQkFBVyxJQUFJO0FBQUEsUUFDbkIsR0FBRyxHQUFJO0FBQ1BFLGtCQUFVLFNBQVM7QUFBQSxNQUN2QixTQUFTbUIsT0FBTztBQUNackIsbUJBQVdxQixNQUFNdEIsT0FBTztBQUFBLE1BQzVCO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFQSxTQUNJLHVCQUFDLFNBQUksT0FBTyxFQUFDd0QsU0FBUyxRQUFRQyxlQUFlLFVBQVVDLGdCQUFnQixVQUFVQyxZQUFZLFNBQVEsR0FDakc7QUFBQSwyQkFBQyxRQUFHLE9BQU8sRUFBQ2xGLFFBQVEsT0FBTSxHQUFHLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDO0FBQUEsSUFDbEMsdUJBQUMsZ0JBQWEsU0FBa0IsVUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQzlDcUIsU0FBUyxPQUNKMEIsVUFBVSxJQUNWLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxVQUFLLE9BQU8sRUFBQy9DLFFBQVEsT0FBTSxHQUFHLFdBQVUsY0FBYTtBQUFBLCtCQUFDLE9BQUdxQixlQUFLOEQsUUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxRQUFJO0FBQUEsV0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQ25GLHVCQUFDLFlBQU8sU0FBU2pDLGNBQWMsT0FBT3pDLFlBQVksdUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxNQUN6RCx1QkFBQyxTQUFJLE9BQU8sRUFBQ1QsUUFBUSxPQUFNLEdBQ3RCMkIsd0JBQ0dnQyxlQUFlLElBRWYsdUJBQUMsWUFBTyxTQUFTQyxzQkFBc0IsT0FBT2hFLGNBQWMsd0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0UsS0FKNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxRQUFHLE9BQU9jLGVBQWUsU0FBUzZELGFBQWEsNEJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUM1RCx1QkFBQyxTQUFJLE9BQU8sRUFBQ3ZFLFFBQVEsT0FBTSxHQUN0QmMsZ0JBQU13RDtBQUFBQSxRQUFJLENBQUFqQixTQUNQO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDSztBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBO0FBQUEsVUFKS0EsS0FBS1M7QUFBQUEsVUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlpQjtBQUFBLE1BRXJCLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCRjtBQUFBLE9BMUJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0QkE7QUFFUjtBQUFDakQsR0FqTEtELEtBQUc7QUFBQXdFLEtBQUh4RTtBQW1MTixlQUFlQTtBQUFHLElBQUF3RTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiQmxvZyIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiTm90aWZpY2F0aW9uIiwiQmxvZ0Zvcm0iLCJidXR0b25zdHlsZXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJjb2xvciIsInBhZGRpbmciLCJtYXJnaW4iLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJib3JkZXJDb2xvciIsImZvbnRGYW1pbHkiLCJmb250U2l6ZSIsInRleHRBbGlnbiIsImN1cnNvciIsIm91dGxpbmUiLCJidXR0b25XYXJuIiwicG9wdWxhclN0eWxlcyIsIndpZHRoIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwidXNlU3RhdGUiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJmb3JtVmlzaWJsZSIsInNldEZvcm1WaXNpYmxlIiwiZ2V0QWxsIiwidGhlbiIsImxvZ2dlZFVzZXIiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsImVycm9yIiwic2V0VGltZW91dCIsImxvZ2luRm9ybSIsInRhcmdldCIsInZhbHVlIiwiaGFuZGxlTG9nb3V0IiwiY2xlYXIiLCJhZGRCbG9nIiwiYmxvZyIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwicmVzcG9uc2UiLCJjcmVhdGUiLCJjcmVhdGVCbG9nRm9ybSIsInRvZ2dsZUZvcm1WaXNpYmlsaXR5IiwiaGFuZGxlTGlrZSIsImlkIiwiZm91bmRCbG9nIiwiZmluZCIsImIiLCJ1cGRhdGVkTGlrZXMiLCJsaWtlcyIsInVwZGF0ZUxpa2VzIiwidXBkYXRlZEJsb2dzIiwibWFwIiwic2hvd1BvcHVsYXIiLCJzb3J0ZWRCeUxpa2VzIiwic29ydCIsImEiLCJkZWxldGVCbG9nIiwiY29uZmlybSIsInByZXZCbG9ncyIsImZpbHRlciIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVN0YXRlLCB1c2VFZmZlY3R9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbi5qcydcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbi5qc3gnXG5pbXBvcnQgQmxvZ0Zvcm0gZnJvbSAnLi9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCdcblxuY29uc3QgYnV0dG9uc3R5bGVzID0ge1xuICAgIGJhY2tncm91bmRDb2xvcjogJ2xpZ2h0Z3JlZW4nLFxuICAgIGNvbG9yOiAnYmxhY2snLFxuICAgIHBhZGRpbmc6ICc0cHggOHB4JyxcbiAgICBtYXJnaW46ICcxMHB4JyxcbiAgICBib3JkZXJSYWRpdXM6ICc1cHgnLFxuICAgIGJveFNoYWRvdzogJzAnLFxuICAgIGJvcmRlckNvbG9yOiAnaW5oZXJpdCcsXG4gICAgZm9udEZhbWlseTogJ3NhbnMtc2VyaWYnLFxuICAgIGZvbnRTaXplOiAnMTRweCcsXG4gICAgdGV4dEFsaWduOiAnY2VudGVyJyxcbiAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICBvdXRsaW5lOiAnbm9uZSdcbn1cbmNvbnN0IGJ1dHRvbldhcm4gPSB7XG4gICAgYmFja2dyb3VuZENvbG9yOiAnbGlnaHRjb3JhbCcsXG4gICAgY29sb3I6ICdibGFjaycsXG4gICAgcGFkZGluZzogJzRweCA4cHgnLFxuICAgIG1hcmdpbjogJzEwcHgnLFxuICAgIGJvcmRlclJhZGl1czogJzVweCcsXG4gICAgYm94U2hhZG93OiAnMCcsXG4gICAgYm9yZGVyQ29sb3I6ICdpbmhlcml0JyxcbiAgICBmb250RmFtaWx5OiAnc2Fucy1zZXJpZicsXG4gICAgZm9udFNpemU6ICcxNHB4JyxcbiAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgIG91dGxpbmU6ICdub25lJ1xufVxuY29uc3QgcG9wdWxhclN0eWxlcyA9IHtcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICdsaWdodEJsdWUnLFxuICAgIHdpZHRoOiAnMzAlJyxcbiAgICBjb2xvcjogJ2JsYWNrJyxcbiAgICBwYWRkaW5nOiAnNHB4IDhweCcsXG4gICAgbWFyZ2luOiAnMTBweCcsXG4gICAgYm9yZGVyUmFkaXVzOiAnNXB4JyxcbiAgICBib3hTaGFkb3c6ICcwJyxcbiAgICBib3JkZXJDb2xvcjogJ2luaGVyaXQnLFxuICAgIGZvbnRGYW1pbHk6ICdzYW5zLXNlcmlmJyxcbiAgICBmb250U2l6ZTogJzE0cHgnLFxuICAgIHRleHRBbGlnbjogJ2NlbnRlcicsXG4gICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgb3V0bGluZTogJ25vbmUnXG59XG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuXG4gICAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICAgIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShudWxsKVxuICAgIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZSgnJylcblxuICAgIGNvbnN0IFtmb3JtVmlzaWJsZSwgc2V0Rm9ybVZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbihibG9ncyA9PlxuICAgICAgICAgICAgc2V0QmxvZ3MoYmxvZ3MpXG4gICAgICAgIClcbiAgICB9LCBbXSlcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBsb2dnZWRVc2VyID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRVc2VyJylcbiAgICAgICAgaWYgKGxvZ2dlZFVzZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvZ2dlZFVzZXIpXG4gICAgICAgICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICAgICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgICAgICB9XG4gICAgfSwgW10pXG4gICAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7dXNlcm5hbWUsIHBhc3N3b3JkfSlcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpKVxuICAgICAgICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICAgICAgICAgIHNldFVzZXIodXNlcilcbiAgICAgICAgICAgIHNldFVzZXJuYW1lKCcnKVxuICAgICAgICAgICAgc2V0UGFzc3dvcmQoJycpXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBzZXRNZXNzYWdlKCdXcm9uZyB1c2VybmFtZSBvciBwYXNzd29yZCcpXG4gICAgICAgICAgICBzZXRTdGF0dXMoJ2Vycm9yJylcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UobnVsbClcbiAgICAgICAgICAgIH0sIDIwMDApXG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgbG9naW5Gb3JtID0gKCkgPT4gKFxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3Bhbj51c2VybmFtZSA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIlVzZXJuYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ1c2VybmFtZVwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7dGFyZ2V0fSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuPnBhc3N3b3JkIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIlBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7dGFyZ2V0fSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5sb2cgaW48L2J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuICAgIClcbiAgICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UuY2xlYXIoKTtcbiAgICAgICAgc2V0VXNlcihudWxsKTtcbiAgICB9XG4gICAgY29uc3QgYWRkQmxvZyA9IGFzeW5jIChibG9nKSA9PiB7XG4gICAgICAgIGlmICghYmxvZy50aXRsZSB8fCAhYmxvZy5hdXRob3IgfHwgIWJsb2cudXJsKSB7XG4gICAgICAgICAgICBzZXRNZXNzYWdlKCdUaXRsZSwgYXV0aG9yLCBhbmQgdXJsIG11c3Qgbm90IGJlIGVtcHR5JylcbiAgICAgICAgICAgIHNldFN0YXR1cygnZXJyb3InKVxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0TWVzc2FnZShudWxsKVxuICAgICAgICAgICAgfSwgMjAwMClcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlKGJsb2cpXG4gICAgICAgICAgICBzZXRNZXNzYWdlKGBBZGRlZCAke3Jlc3BvbnNlLnRpdGxlfWApXG4gICAgICAgICAgICBzZXRTdGF0dXMoJ3N1Y2Nlc3MnKVxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0TWVzc2FnZShudWxsKVxuICAgICAgICAgICAgfSwgMjAwMClcbiAgICAgICAgICAgIHNldEJsb2dzKFsuLi5ibG9ncywgcmVzcG9uc2VdKVxuICAgICAgICAgICAgc2V0Rm9ybVZpc2libGUoZmFsc2UpXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpXG4gICAgICAgICAgICBzZXRTdGF0dXMoJ2Vycm9yJylcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UobnVsbClcbiAgICAgICAgICAgIH0sIDIwMDApXG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgY3JlYXRlQmxvZ0Zvcm0gPSAoKSA9PiB7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxCbG9nRm9ybVxuICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlQmxvZz17YWRkQmxvZ31cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRGb3JtVmlzaWJsZShmYWxzZSl9IHN0eWxlPXtidXR0b25XYXJufT5jYW5jZWw8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApXG4gICAgfVxuICAgIGNvbnN0IHRvZ2dsZUZvcm1WaXNpYmlsaXR5ID0gKCkgPT4ge1xuICAgICAgICBzZXRGb3JtVmlzaWJsZSghZm9ybVZpc2libGUpXG4gICAgfVxuICAgIGNvbnN0IGhhbmRsZUxpa2UgPSBhc3luYyAoaWQpID0+IHtcbiAgICAgICAgY29uc3QgZm91bmRCbG9nID0gYmxvZ3MuZmluZChiID0+IGIuaWQgPT09IGlkKVxuICAgICAgICBpZiAoZm91bmRCbG9nKSB7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkTGlrZXMgPSB7Li4uZm91bmRCbG9nLCBsaWtlczogZm91bmRCbG9nLmxpa2VzICsgMX1cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBibG9nU2VydmljZS51cGRhdGVMaWtlcyhpZCwgdXBkYXRlZExpa2VzKVxuICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRCbG9ncyA9IGJsb2dzLm1hcChiID0+IGIuaWQgPT09IGlkID8gcmVzcG9uc2UgOiBiKVxuICAgICAgICAgICAgICAgIHNldEJsb2dzKHVwZGF0ZWRCbG9ncylcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHNob3dQb3B1bGFyID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBzb3J0ZWRCeUxpa2VzID0gWy4uLmJsb2dzXS5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcbiAgICAgICAgc2V0QmxvZ3Moc29ydGVkQnlMaWtlcylcbiAgICB9XG4gICAgY29uc3QgZGVsZXRlQmxvZyA9IGFzeW5jIChpZCkgPT4ge1xuICAgICAgICBjb25zdCBmb3VuZEJsb2cgPSBibG9ncy5maW5kKGIgPT4gYi5pZCA9PT0gaWQpXG4gICAgICAgIGlmIChmb3VuZEJsb2cgJiYgd2luZG93LmNvbmZpcm0oYERlbGV0ZSAke2ZvdW5kQmxvZy50aXRsZX0gYnkgJHtmb3VuZEJsb2cuYXV0aG9yfT9gKSkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBibG9nU2VydmljZS5kZWxldGVCbG9nKGZvdW5kQmxvZy5pZClcbiAgICAgICAgICAgICAgICBzZXRCbG9ncyhwcmV2QmxvZ3MgPT4gcHJldkJsb2dzLmZpbHRlcihiID0+IGIuaWQgIT09IGZvdW5kQmxvZy5pZCkpXG4gICAgICAgICAgICAgICAgc2V0TWVzc2FnZShgRGVsZXRlZCAke2ZvdW5kQmxvZy50aXRsZX1gKVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRNZXNzYWdlKG51bGwpXG4gICAgICAgICAgICAgICAgfSwgMzAwMClcbiAgICAgICAgICAgICAgICBzZXRTdGF0dXMoJ3N1Y2Nlc3MnKVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IHN0eWxlPXt7ZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCBhbGlnbkl0ZW1zOiAnY2VudGVyJ319PlxuICAgICAgICAgICAgPGgyIHN0eWxlPXt7bWFyZ2luOiAnMjBweCd9fT5CbG9nczwvaDI+XG4gICAgICAgICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e21lc3NhZ2V9IHN0YXR1cz17c3RhdHVzfS8+XG4gICAgICAgICAgICB7dXNlciA9PT0gbnVsbFxuICAgICAgICAgICAgICAgID8gbG9naW5Gb3JtKClcbiAgICAgICAgICAgICAgICA6IDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7bWFyZ2luOiAnMTBweCd9fSBjbGFzc05hbWU9XCJsb2dnZWRVc2VyXCI+PGI+e3VzZXIubmFtZX08L2I+IGxvZ2dlZCBpbiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fSBzdHlsZT17YnV0dG9uV2Fybn0+bG9nIG91dDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7bWFyZ2luOiAnMTBweCd9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtVmlzaWJsZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjcmVhdGVCbG9nRm9ybSgpXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlRm9ybVZpc2liaWxpdHl9IHN0eWxlPXtidXR0b25zdHlsZXN9PmFkZCBibG9nPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIHN0eWxlPXtwb3B1bGFyU3R5bGVzfSBvbkNsaWNrPXtzaG93UG9wdWxhcn0+U2hvdyBwb3B1bGFyPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e21hcmdpbjogJzEwcHgnfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YmxvZ3MubWFwKGJsb2cgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmxvZyBrZXk9e2Jsb2cuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvZz17YmxvZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVMaWtlPXtoYW5kbGVMaWtlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZUJsb2c9e2RlbGV0ZUJsb2d9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiJDOi9Vc2Vycy9la3JhL1dlYnN0b3JtUHJvamVjdHMvZnNvcGVuL3BhcnQ1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9BcHAuanN4In0=